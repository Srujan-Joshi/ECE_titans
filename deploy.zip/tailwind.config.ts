import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
      },
      keyframes: {
        flowAnimation: {
          from: { strokeDashoffset: "0" },
          to: { strokeDashoffset: "-100" },
        },
      },
      animation: {
        flow: "flowAnimation 10s linear infinite",
      },
    },
  },
  plugins: [],
};

export default config;
